class Path:
    def __init__(self, office_x,office_y,customer_x,customer_y,path):
        self.office_x=office_x
        self.office_y=office_y
        self.customer_x=customer_x
        self.customer_y=customer_y
        self.path=path

