class Customer():

    def __init__(self,row ,col ,reward):
        self.row = int(row)
        self.col = int(col)
        self.reward = int(reward)

